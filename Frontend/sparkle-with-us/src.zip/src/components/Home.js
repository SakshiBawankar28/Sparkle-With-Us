import React from 'react';
// import './Style.css';
import './css/Style.css';


const Home = () => {
  return (
    <div className="home">
      <h1>Welcome to Our Sparkle With Us Parlour</h1>
      <p>Your beauty, our duty.</p>
    </div>
  );
}

export default Home;
