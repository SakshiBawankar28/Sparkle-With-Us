import React from 'react';
// import './Style.css';
import './css/Style.css';



const Footer = () => {
  return (
    <footer className="footer">
      <p>&copy; 2024 Sparkle With Us Parlour. All Rights Reserved.</p>
    </footer>
  );
}

export default Footer;
