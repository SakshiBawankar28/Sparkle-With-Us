package com.app.entities;

public enum Gender 
{
	FEMALE,MALE,OTHERS;
}