package com.app.entities;

public enum Specialization 
{
	HAIRCUTS, NAIL_ARTIST, WAXING_SPECIALIST, MAKEUP_ARTIST;
}
